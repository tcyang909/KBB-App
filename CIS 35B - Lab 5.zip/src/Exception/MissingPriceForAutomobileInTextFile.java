package Exception;

public class MissingPriceForAutomobileInTextFile extends Exception{
	public MissingPriceForAutomobileInTextFile(String message){
		super(message);
	}
}
