package Exception;

public class FileNameNotFound extends Exception{
	public FileNameNotFound(String message){
		super(message);
	}
}
