package Server;

import Adapter.ProxyAutomobile;

public class BuildCarModelOptions extends ProxyAutomobile implements AutoServer{
	
}
