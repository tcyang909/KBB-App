package Adapter;

import Server.AutoServer;

public class BuildAuto extends ProxyAutomobile implements CreateAuto, UpdateAuto, ScaleThread, AutoServer{
}
