package Exception;

public class AutoException extends Exception{
	public AutoException(){}
	public AutoException(String msg){
		super(msg);
	}
}
