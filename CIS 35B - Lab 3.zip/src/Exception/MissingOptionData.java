package Exception;

public class MissingOptionData extends Exception{
	public MissingOptionData(String message){
		super(message);
	}
}
