package Exception;

public class MissingOptionChoice extends Exception{
	public MissingOptionChoice(String message){
		super(message);
	}
}
