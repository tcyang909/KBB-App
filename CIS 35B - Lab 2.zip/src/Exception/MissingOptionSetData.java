package Exception;

public class MissingOptionSetData extends Exception{
	public MissingOptionSetData(String message){
		super(message);
	}
}
