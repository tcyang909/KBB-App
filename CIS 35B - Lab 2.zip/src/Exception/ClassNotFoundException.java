package Exception;

public class ClassNotFoundException extends Exception{
	public ClassNotFoundException(){}
	public ClassNotFoundException(String msg){
		super(msg);
	}
}
