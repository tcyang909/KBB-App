package Adapter;

import java.io.IOException;

import Exception.FileNameNotFound;
import Exception.MissingOptionData;
import Exception.MissingOptionSetData;
import Exception.MissingPriceForAutomobileInTextFile;
import Model.*;
import Util.*;

public abstract class ProxyAutomobile{
	private static Automobile a1;		//why do we use static obj in proxy auto. ansswer is bec working with w interface, creat update.
	
	public void buildAuto(String fileName) throws MissingPriceForAutomobileInTextFile, MissingOptionSetData, MissingOptionData, IOException{
		AutomobileBuilder autoBuilder = new AutomobileBuilder();
		a1 = autoBuilder.buildAutoObject(fileName);
		FileIO.serializeAuto(a1);
	}
	public void printAuto(String modelName) throws IOException{
		Automobile auto = null;
		String carName = modelName + ".ser";
		auto = FileIO.deserializeAuto(carName);
		auto.print();
	}
	public void updateOptionSetName(String modelName, String optionSetName,String newName) throws IOException {
		Automobile auto = null;
		String carName = modelName + ".ser";
		auto = FileIO.deserializeAuto(carName);
		auto.updateOptionSetName(optionSetName, newName);
		auto.print();
		FileIO.serializeAuto(auto);
	}
	public void updateOptionPrice(String modelName, String optionName,String Option, float newPrice) throws IOException {
		Automobile auto = null;
		String carName = modelName + ".ser";
		auto = FileIO.deserializeAuto(carName);
		auto.updateOptionPrice(optionName, Option, newPrice);
		auto.print();
		FileIO.serializeAuto(auto);
	}
}
