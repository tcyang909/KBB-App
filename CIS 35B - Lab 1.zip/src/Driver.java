

import Model.Automotive;
import Util.FileIO;
import java.io.*;

public class Driver extends FileIO{
	
	public static void main(String[] args) throws ClassNotFoundException, IOException {
		
		Driver CIS35b = new Driver();
		Automotive FordZTW = new Automotive();
		CIS35b.buildAutoObject("FordZTW.txt", FordZTW);
		FordZTW.print();
		
		CIS35b.serializeAuto(FordZTW);
		//CIS35b.DeserializeAuto("save.ser");
		Automotive newFordZTW = CIS35b.deserializeAuto("save.ser");
	    newFordZTW.print();
	}
}
