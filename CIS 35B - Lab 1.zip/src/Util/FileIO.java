package Util;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import Model.Automotive;

public class FileIO {
	
	public void readSource(String fileName){
		try{
			FileReader file = new FileReader(fileName);
			BufferedReader buff = new BufferedReader(file);
			boolean eof = false;
			while (!eof){
				String line = buff.readLine();
				if (line == null)
					eof = true;
				else
					System.out.println(line);
			}
			buff.close();
		} catch (IOException e){
			System.out.println("Error -- " + e.toString());
		}
	}
	
	public boolean isInteger (String input){
		char c = input.charAt(0);
		if (c <= '/' || c >= ':')
			return false;
		else
			return true;
	}
	public void buildAutoObject(String filename, Automotive a1){
		try{
			FileReader file = new FileReader(filename);
			BufferedReader buff = new BufferedReader(file);
			boolean eof = false, noMoreOpt = true;
			int opsetNum = -1, lineNum = 1, optNum = 0, optNumCap = 0;
			while (!eof){
				String line = buff.readLine();
				
				if (line == null)
					eof = true;
					
				else if (line.isEmpty()) {
					System.out.println(line);
					continue;
				}
				else{
					System.out.println(line);	
												
					if(optNum == optNumCap){								//trigger if no more input for options in the optionSet
						noMoreOpt = true;
						optNumCap = 0;
						optNum = 0;
					}
					if(lineNum == 1){										//name of car
						a1.setName(line);
						a1.setBasePrice(18445);
					}
					else if (lineNum == 2){										//input amount of option sets 
						a1.setOpset(Integer.parseInt(line));
					}
					
					else if(isInteger(line) == true){							//
						int i = Integer.parseInt(line);							
						opsetNum++;												
						a1.setOptNum(opsetNum, i);								
						optNumCap = i;										
					}
					else if(isInteger(line) != true && noMoreOpt == true){
						a1.setOpsetName(line, opsetNum);
						noMoreOpt = false;
					}
					else if(isInteger(line) != true && noMoreOpt != true ){
						a1.setOpt(opsetNum, optNum, line);
						optNum++;
					}	
				}
				//System.out.printf("OPTNUM: %d", optNum);
				lineNum++;
			}
			buff.close();
		} catch (IOException e){
			System.out.println("Error -- " + e.toString());
		}
		//return a1;
	}
	public void serializeAuto(Automotive auto) throws IOException, ClassNotFoundException{
		try{
		ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("save.ser"));
		out.writeObject(auto);
		out.close();
		}catch(IOException e){
			e.printStackTrace();
		}
	}
	public Automotive deserializeAuto(String autoName) throws FileNotFoundException, IOException{
		Automotive a = null;
		try{
			ObjectInputStream ois = new ObjectInputStream( new FileInputStream(autoName));
			a = (Automotive) ois.readObject();
			ois.close();
			
			//Automotive restore = (Automotive) ois.readObject();
			//Enumeration e = restore.elements();
			//while ( a.hasMoreElements() )
			    //System.out.println( a.nextElement() );
		}catch(ClassNotFoundException e){
			System.out.println("Automotive class not found");
			e.printStackTrace();
		}
		return a;
	}
}

