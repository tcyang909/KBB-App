package Exception;

public class ClassNotFoundException {

}
