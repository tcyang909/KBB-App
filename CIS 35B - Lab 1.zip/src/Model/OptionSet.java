package Model;

public class OptionSet implements java.io.Serializable {
	private String name;
	Option opt[];
	
	OptionSet(){
		this.opt = null;
	}
	OptionSet(String name){
		this.name = name;
		this.opt = null;
	}
	OptionSet(String name, int size){
		opt = new Option[size];
		for (int j = 0; j < opt.length; j++)
			opt[j] = new Option();
		this.name = name;
		
	}
	
	protected String getName() {
		return name;
	}
	protected void setName(String name) {
		this.name = name;
	}
	protected Option[] getOpt() {
		return opt;
	}
	protected void setOptNum(int x){
		this.opt = new Option[x];
	}
	protected void setOpt(Option opt[]) {
		this.opt = opt;
	}
	protected void setOpt(int i, String name){
		this.opt[i] = new Option(name);
	}
	protected void setOpt(int i, String name, int price){
		this.opt[i] = new Option(name, price);
	}
	protected Option getOpt(String name){
		for (int i = 0; i < opt.length; i++)
			if (name.equals(opt[i]))
				return opt[i];
		return null;
	}
	protected int getOptPrice (String name){
		for (int i = 0; i < opt.length; i++)
			if (name.equals(opt[i]))
				return opt[i].getPrice();
		return -1;
	}
	protected int findOpt (String name){
		for (int i = 0; i < opt.length; i++)
			if (name.equals(opt[i]))
				return i;
		return -1;
	}
	protected void delete (int x){
		opt[x] = null;
		opt[x] = new Option();
	}
	protected void print(){
		System.out.printf("Name: %s", name);
	}
}
