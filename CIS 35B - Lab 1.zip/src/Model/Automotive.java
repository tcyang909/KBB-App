package Model;

public class Automotive implements java.io.Serializable {
	private String name;
	private float basePrice;
	OptionSet opset[];
	
	public Automotive() {}
	Automotive(String n, float price, int size){
		opset = new OptionSet[size];
		for (int i = 0; i < opset.length; i++)
			opset[i] = new OptionSet();
		this.basePrice = price;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getBasePrice() {
		return basePrice;
	}
	public void setBasePrice(float basePrice) {
		this.basePrice = basePrice;
	}
	public OptionSet getOpset(int x) {
		return opset[x];
	}
	public OptionSet findOpset(String name){
		for (int i = 0; i < opset.length; i++)
			if (opset[i].getName().equals(name))
				return opset[i];
		return null;
	}
	public Option findOpt(String name){
		for (int i = 0; i < opset.length; i++)
			for (int j = 0; j < opset[i].opt.length; j++)
				if (opset[i].opt[j].getName().equals(name))
					return opset[i].opt[j];
		return null;
	}
	public void setOpset (int x){
		this.opset = new OptionSet[x];
		for (int i = 0; i < opset.length; i++)
			opset[i] = new OptionSet();
	}
	public void setOptNum (int OpsetNum, int optNum){
		this.opset[OpsetNum].setOptNum(optNum);
	}
	public void setOpset(OptionSet opset, int x) {
		this.opset[x] = opset;
	}
	public void setOpsetName(String name, int x) {
		this.opset[x].setName(name);
	}
	public void setOpt(int x, int optNum, String optName){
		this.opset[x].setOpt(optNum, optName);
	}
	public void setOpt(OptionSet opset, Option opt, int x){
		opset.opt[x] = opt;
	}
	public void deleteOptionSet (int x){		
		//opset[x] = ArrayUtils.removeElement(optset[x], element);
		opset[x] = null;
		opset[x] = new OptionSet();
	}
	public void deleteOption (OptionSet opset, int x){
		opset.opt[x] = null;
		opset.opt[x] = new Option();
	}
	public void updateOptionSet(OptionSet NewOpset, int x){
		opset[x] = null;
		opset[x] = NewOpset;
	}
	public void updateOption(OptionSet opset, Option opt, int x){
		opset.opt[x] = null;
		opset.opt[x] = opt;
	}
	public void print(){
		System.out.printf("\nPrinting Automotive:");
		System.out.printf("\nName: %s", this.name);
		System.out.printf("\nBase Price: %.2f", this.basePrice);
		for (int r = 0; r < this.opset.length; r++){
			System.out.printf("\nOption: %s", this.opset[r].getName());
			for (int c = 0; c < opset[r].opt.length; c++){
				//System.out.println(opset[r].opt.length);
				System.out.printf("\n%d: %s", c+1, this.opset[r].opt[c].getName());
			}
		}
		System.out.printf("\nEnd of Printing\n");
	}
}
